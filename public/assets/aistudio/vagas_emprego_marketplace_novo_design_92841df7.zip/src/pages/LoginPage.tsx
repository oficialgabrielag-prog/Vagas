import React, { useState, useEffect } from 'react';
import { Briefcase, Mail, Lock, CheckCircle2, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { UserProfile } from '../lib/types';
import { StoreService } from '../lib/store';
import { supabase } from '../lib/supabase';
import { AnimatedBrandLogo } from '../components/AnimatedBrandLogo';
import { verifyRecaptchaAction, getRecaptchaSiteKey, loadRecaptchaScript } from '../lib/recaptcha';

interface LoginPageProps {
  onLoginSuccess: (user: UserProfile) => void;
  onNavigateToRegister: () => void;
  onNavigateToHome: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  onNavigateToRegister,
  onNavigateToHome
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isForgot, setIsForgot] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Pré-carrega o script do reCAPTCHA v3 de forma assíncrona para que a validação seja instantânea
  useEffect(() => {
    const siteKey = getRecaptchaSiteKey();
    if (siteKey) {
      loadRecaptchaScript(siteKey).catch(() => {});
    }
  }, []);

  const handleFacebookLogin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'facebook',
        options: {
          redirectTo: 'https://gdjyrgufdjboqkusredk.supabase.co/auth/v1/callback'
        }
      });
      if (error) {
        alert('Erro Facebook: ' + error.message);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (isForgot) {
      if (!email.trim()) {
        setError('Por favor, introduza o seu endereço de email.');
        return;
      }
      setLoading(true);
      try {
        // Verificação segura do reCAPTCHA v3 para ação forgot_password
        const captchaResult = await verifyRecaptchaAction('forgot_password');
        if (!captchaResult.success) {
          setError(captchaResult.error || 'Verificação de segurança reCAPTCHA falhou. Tente novamente.');
          setLoading(false);
          return;
        }

        await StoreService.resetPassword(email.trim());
        setSuccessMessage('Instruções de recuperação enviadas para o seu email!');
      } catch (err: any) {
        setError(err.message || 'Erro ao enviar email de recuperação.');
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!email.trim() || !password) {
      setError('Por favor, preencha o seu email e palavra-passe.');
      return;
    }

    setLoading(true);
    try {
      // Verificação segura do reCAPTCHA v3 para ação login
      const captchaResult = await verifyRecaptchaAction('login');
      if (!captchaResult.success) {
        setError(captchaResult.error || 'Verificação de segurança reCAPTCHA falhou. Tente novamente.');
        setLoading(false);
        return;
      }

      const user = await StoreService.loginWithSupabase(email.trim(), password);
      onLoginSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Dados de acesso incorretos. Verifique o email e a palavra-passe.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col justify-between py-8 px-4 sm:px-6 lg:px-8 font-sans selection:bg-[#1d5fc4] selection:text-white">
      {/* Top Header Branding Centered with Animated Letters */}
      <div className="max-w-md w-full mx-auto flex items-center justify-center pt-2">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 bg-[#1d5fc4] rounded-xl flex items-center justify-center text-white shadow-xs">
            <Briefcase className="w-5 h-5 text-[#f0b823]" />
          </div>
          <AnimatedBrandLogo mode="active" size="lg" />
        </div>
      </div>

      {/* Main Login Form without White Card Container */}
      <div className="max-w-md w-full mx-auto my-auto space-y-6 py-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            {isForgot ? 'Recuperar Palavra-passe' : 'Bem-vindo de volta'}
          </h1>
          <p className="text-sm text-slate-500 leading-relaxed max-w-sm mx-auto">
            {isForgot
              ? 'Introduza o seu email para receber as instruções de recuperação.'
              : 'Inicie sessão para gerir as suas candidaturas ou anúncios de emprego no Cunene.'}
          </p>
        </div>

        {/* Feedback Alerts */}
        {error && (
          <div className="bg-rose-50 text-rose-700 p-4 rounded-xl text-sm border border-rose-100 flex items-start gap-3 animate-fadeIn">
            <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
            <div className="font-medium">{error}</div>
          </div>
        )}

        {successMessage && (
          <div className="bg-emerald-50 text-emerald-700 p-4 rounded-xl text-sm border border-emerald-100 flex items-start gap-3 animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div className="font-medium">{successMessage}</div>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-sm font-semibold text-slate-700">
              Email
            </label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="exemplo@cunenevagas.online"
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-[#1d5fc4] focus:ring-1 focus:ring-[#1d5fc4] transition-all bg-white"
              />
            </div>
          </div>

          {!isForgot && (
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="block text-sm font-semibold text-slate-700">
                  Palavra-passe
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setIsForgot(true);
                    setError('');
                    setSuccessMessage('');
                  }}
                  className="text-xs text-[#1d5fc4] font-bold hover:text-[#174fa8]"
                >
                  Esqueceu-se?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-11 pr-11 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-[#1d5fc4] focus:ring-1 focus:ring-[#1d5fc4] transition-all bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#1d5fc4] hover:bg-[#174fa8] text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-sm active:scale-[0.98] flex items-center justify-center disabled:opacity-60 cursor-pointer mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <span>{isForgot ? 'Enviar recuperação' : 'Entrar na minha conta'}</span>
            )}
          </button>

          {!isForgot && (
            <>
              <div className="flex items-center gap-2 my-3">
                <div className="h-px flex-1 bg-gray-200"></div>
                <span className="text-xs text-gray-400 font-bold">OU</span>
                <div className="h-px flex-1 bg-gray-200"></div>
              </div>

              <button
                type="button"
                onClick={handleFacebookLogin}
                disabled={loading}
                className="bg-white border border-gray-300 rounded-lg h-12 w-full flex items-center justify-center gap-3 hover:bg-gray-50 transition shadow-xs cursor-pointer disabled:opacity-60"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="#1877F2">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span className="font-medium text-gray-700">
                  {loading ? 'A redirecionar...' : 'Continuar com Facebook'}
                </span>
              </button>
            </>
          )}
        </form>

        {/* Toggle between Login, Register, Forgot */}
        <div className="pt-4 text-center">
          {isForgot ? (
            <p className="text-sm text-slate-600">
              Lembrou-se da palavra-passe?{' '}
              <button
                type="button"
                onClick={() => {
                  setIsForgot(false);
                  setError('');
                  setSuccessMessage('');
                }}
                className="text-[#1d5fc4] font-bold hover:underline"
              >
                Voltar ao início
              </button>
            </p>
          ) : (
            <p className="text-sm text-slate-600">
              Ainda não tem conta?{' '}
              <button
                type="button"
                onClick={onNavigateToRegister}
                className="text-[#1d5fc4] font-bold hover:underline"
              >
                Registe-se agora
              </button>
            </p>
          )}
        </div>
      </div>

      {/* Footer copyright */}
      <div className="text-center text-xs text-slate-400 mt-6 font-medium">
        © {new Date().getFullYear()} CuneneVagas • Oportunidades & Negócios no Cunene
      </div>
    </div>
  );
};
