# Alterações de design (apenas visual)

Nenhuma função, rota, tipo, prop, chamada ao Supabase ou conteúdo de utilizador foi alterado.

1. `index.html`: carrega as fontes DM Sans e Fraunces.
2. `src/index.css`: títulos h1 a h3 em Fraunces, sombras mais suaves, peso `font-black` passa a 800, foco visível, respeito por `prefers-reduced-motion`.
3. Paleta: cores antigas trocadas por cores novas em todos os ficheiros de `src` (mesmo formato `#hex`, nenhuma classe renomeada).
   - Azul principal `#0F4C9C` / `#1A73E8` → `#1d5fc4`; azuis escuros → `#14305f`, `#173a6e`, `#0f2a52`
   - Amarelo `#FFC20E` / `#F5B91B` / `#FFB900` → `#f0b823`
   - Fundos `#E8F4FC` / `#F8FAFC` → `#f3f5f8` / `#f6f8fb`; linhas → `#dde5f0` / `#e0e6ee`
   - Textos → `#16213a`, `#243049`, `#5d6778`
4. `GiantCinematicCarousel.tsx`: indicadores passam a barras finas (só classes).
5. `BottomNav.tsx`: separador ativo em azul com fundo suave (só classes).
